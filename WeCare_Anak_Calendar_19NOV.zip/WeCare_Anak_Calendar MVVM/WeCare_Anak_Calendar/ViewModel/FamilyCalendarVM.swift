//
//  FamilyCalendarVM.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 13/11/25.
//
import Foundation
import Combine
import SwiftUI


@MainActor
final class FamilyCalendarViewModel: ObservableObject {

    // UI state
    @Published var selectedDate: Date = Date()
    @Published var currentMonthOffset = 0
    @Published var selectedPerson: PersonCardViewData? = nil
    
    // Add-agenda sheet state
    @Published var showingAddAgenda = false
    @Published var newAgendaTitle = ""
    @Published var newAgendaDescription = ""
    @Published var newAgendaOwner: PersonCardViewData? = nil
    @Published var newAgendaStatus: UrgencyStatus = .low
    @Published var newAgendaTimeDate = Date()
    
    // Add Agenda Type
    @Published var newAgendaType: AgendaType = .activity
    @Published var editAgendaType: AgendaType = .activity
    
    // Agenda detail
    @Published var selectedAgenda: AgendaItem? = nil
    @Published var showingAgendaDetail = false
    
    // Edit Agenda
    @Published var showingEditAgenda = false
    @Published var editAgendaOriginal: AgendaItem? = nil

    @Published var editAgendaTitle = ""
    @Published var editAgendaDescription = ""
    @Published var editAgendaTimeDate = Date()
    @Published var editAgendaStatus: UrgencyStatus = .low
    @Published var editAgendaOwner: PersonCardViewData? = nil

    // Data
    let persons = SampleData.demoList
    
    // health sample (kept local for calendar color)
    let healthData: [String: [Int: UrgencyStatus]] = [
        "Grandma Siti": [1: .low, 2: .medium, 5: .high, 10: .critical, 15: .low],
        "Grandpa Budi": [3: .low, 6: .high, 9: .medium, 13: .critical],
        "Uncle Rudi": [4: .critical, 8: .medium, 11: .high, 20: .low],
    ]
    
    // agendaData keyed by ownerName -> dateKey -> [AgendaItem]
    @Published var agendaData: [String: [String: [AgendaItem]]] = [:]
    
    init() {
        // seed with some demo agendas
        agendaData = [
            "Grandma Siti": [
                "2025-11-13": [.init(title: "Check blood pressure", description: "Bring meter and record", time: "08:00 AM", status: .low, owner: "Grandma Siti")],
                "2025-11-14": [.init(title: "Take regular medication", description: "Take after breakfast", time: "10:00 AM", status: .medium, owner: "Grandma Siti")]
            ],
            "Grandpa Budi": [
                "2025-11-03": [.init(title: "Leg therapy", description: "Physio at clinic", time: "09:00 AM", status: .high, owner: "Grandpa Budi")]
            ]
        ]
    }
    
    // computed values for view
    var currentDate: Date {
        Calendar.current.date(byAdding: .month, value: currentMonthOffset, to: Date()) ?? Date()
    }
    
    var currentMonthName: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: currentDate)
    }
    
    var daysInMonth: Int {
        Calendar.current.range(of: .day, in: .month, for: currentDate)?.count ?? 30
    }
    
    var currentAgenda: [AgendaItem] {
        let key = dateKey(from: selectedDate)
        if let person = selectedPerson {
            return agendaData[person.name]?[key] ?? []
        } else {
            return persons.flatMap { agendaData[$0.name]?[key] ?? [] }
        }
    }
    
    func deleteAgenda(_ agenda: AgendaItem) {
        let key = dateKey(from: selectedDate)

        // If a specific person is filtered
        if let person = selectedPerson {
            var personAgendas = agendaData[person.name] ?? [:]
            var agendasForDay = personAgendas[key] ?? []

            agendasForDay.removeAll { $0.id == agenda.id }

            if agendasForDay.isEmpty {
                personAgendas.removeValue(forKey: key)
            } else {
                personAgendas[key] = agendasForDay
            }

            agendaData[person.name] = personAgendas
            return
        }

        // When filter is "ALL"
        for person in persons {
            var personAgendas = agendaData[person.name] ?? [:]
            var agendasForDay = personAgendas[key] ?? []

            let before = agendasForDay.count
            agendasForDay.removeAll { $0.id == agenda.id }

            // If deleted from this person's list, update & break
            if before != agendasForDay.count {
                if agendasForDay.isEmpty {
                    personAgendas.removeValue(forKey: key)
                } else {
                    personAgendas[key] = agendasForDay
                }

                agendaData[person.name] = personAgendas
                break
            }
        }
    }

    // MARK: - Agenda management
    
    func saveNewAgenda() {
        guard let owner = newAgendaOwner else { return }

        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        let timeString = formatter.string(from: newAgendaTimeDate)

        // Build title based on type
        let finalTitle: String
        switch newAgendaType {
        case .activity:
            finalTitle = newAgendaTitle
        case .medicine:
            finalTitle = "💊 " + newAgendaTitle    // auto-label for clarity
        }

        let newItem = AgendaItem(
            title: finalTitle,
            description: newAgendaDescription,
            time: timeString,
            status: newAgendaStatus,
            owner: owner.name
        )

        let key = dateKey(from: selectedDate)

        var personAgendas = agendaData[owner.name] ?? [:]
        var agendasForDay = personAgendas[key] ?? []
        agendasForDay.append(newItem)
        personAgendas[key] = agendasForDay
        agendaData[owner.name] = personAgendas

        // Reset state
        newAgendaTitle = ""
        newAgendaDescription = ""
        newAgendaOwner = nil
        newAgendaStatus = .low
        newAgendaTimeDate = Date()
        newAgendaType = .activity
    }

    
    func startEditing(_ agenda: AgendaItem) {
        selectedAgenda = nil
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) { [weak self] in
                guard let self = self else { return }
                self.prepareEditFields(from: agenda)
                self.showingEditAgenda = true
            }
        
        editAgendaOriginal = agenda
        editAgendaTitle = agenda.title
        editAgendaDescription = agenda.description

        // convert agenda.time (String) → Date
        let f = DateFormatter()
        f.dateFormat = "hh:mm a"
        editAgendaTimeDate = f.date(from: agenda.time) ?? Date()

        editAgendaStatus = agenda.status

        // match owner
        editAgendaOwner = persons.first { $0.name == agenda.owner }

        showingEditAgenda = true
    }
    
    func prepareEditFields(from agenda: AgendaItem) {
        editAgendaOriginal = agenda
        editAgendaTitle = agenda.title
        editAgendaDescription = agenda.description
        editAgendaStatus = agenda.status

        let f = DateFormatter()
        f.dateFormat = "hh:mm a"
        editAgendaTimeDate = f.date(from: agenda.time) ?? Date()

        editAgendaOwner = persons.first(where: { $0.name == agenda.owner })
    }


    func saveEditedAgenda() {
        guard let original = editAgendaOriginal else { return }
        guard let owner = editAgendaOwner else { return }

        let key = dateKey(from: selectedDate)

        let f = DateFormatter()
        f.dateFormat = "hh:mm a"
        let timeString = f.string(from: editAgendaTimeDate)

        let updatedItem = AgendaItem(
            id: original.id,
            title: editAgendaTitle,
            description: editAgendaDescription,
            time: timeString,
            status: editAgendaStatus,
            owner: owner.name
        )

        // Remove old agenda entry
        for person in persons {
            var personAgendas = agendaData[person.name] ?? [:]
            var agendasForDay = personAgendas[key] ?? []

            if agendasForDay.contains(where: { $0.id == original.id }) {
                agendasForDay.removeAll { $0.id == original.id }
                personAgendas[key] = agendasForDay
                agendaData[person.name] = personAgendas
                break
            }
        }

        // Insert updated one
        var newOwnerAgendas = agendaData[owner.name] ?? [:]
        var dayList = newOwnerAgendas[key] ?? []
        dayList.append(updatedItem)
        newOwnerAgendas[key] = dayList
        agendaData[owner.name] = newOwnerAgendas

        showingEditAgenda = false
    }

    // MARK: - Calendar color logic
    func colorForDay(_ day: Int) -> Color {
        var combinedStatuses: [UrgencyStatus] = []
        let key = dateKey(forDay: day, in: currentDate)
        
        if let person = selectedPerson {
            if let healthStatus = healthData[person.name]?[day] {
                combinedStatuses.append(healthStatus)
            }
            if let agendas = agendaData[person.name]?[key] {
                combinedStatuses.append(contentsOf: agendas.map { $0.status })
            }
        } else {
            for person in persons {
                if let healthStatus = healthData[person.name]?[day] {
                    combinedStatuses.append(healthStatus)
                }
                if let agendas = agendaData[person.name]?[key] {
                    combinedStatuses.append(contentsOf: agendas.map { $0.status })
                }
            }
        }
        
        if combinedStatuses.contains(.critical) { return Color(hex: "#fa6255") }
        if combinedStatuses.contains(.high) { return Color(hex: "#fdcb46") }
        if combinedStatuses.contains(.medium) { return Color(hex: "#91bef8") }
        if combinedStatuses.contains(.low) { return Color(hex: "#a6d17d") }
        return Color.gray.opacity(0.15)
    }
}
