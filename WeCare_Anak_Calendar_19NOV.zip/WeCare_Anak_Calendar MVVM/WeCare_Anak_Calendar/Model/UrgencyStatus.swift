//
//  UrgencyStatus.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 13/11/25.
//

import Foundation

enum UrgencyStatus: String, Codable, CaseIterable {
    case low, medium, high, critical, none
}
