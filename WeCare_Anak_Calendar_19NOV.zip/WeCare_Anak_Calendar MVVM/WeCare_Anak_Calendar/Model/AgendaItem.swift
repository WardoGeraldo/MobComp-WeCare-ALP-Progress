//
//  AgendaItem.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 13/11/25.
//

import Foundation

enum AgendaType: String, Codable {
    case activity = "Activity"
    case medicine = "Medicine"

    var id: String { rawValue }
}

struct AgendaItem: Identifiable, Hashable {
    var id: UUID
    var title: String
    var description: String
    var time: String
    var status: UrgencyStatus
    var owner: String

    // Custom initializer (Fixes your error)
    init(
        id: UUID = UUID(),
        title: String,
        description: String,
        time: String,
        status: UrgencyStatus,
        owner: String
    ) {
        self.id = id
        self.title = title
        self.description = description
        self.time = time
        self.status = status
        self.owner = owner
    }
}

