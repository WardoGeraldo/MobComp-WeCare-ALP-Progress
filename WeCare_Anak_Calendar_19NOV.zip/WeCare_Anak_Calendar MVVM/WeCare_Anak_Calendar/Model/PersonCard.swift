//
//  PersonCard.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 13/11/25.
//

import Foundation

struct PersonCardViewData: Identifiable, Hashable, Codable {
    let id: UUID
    let name: String
    let role: String
    let avatarURL: URL?
    let heartRateText: String
    let status: UrgencyStatus
}

enum SampleData {
    static let demoList: [PersonCardViewData] = [
        .init(id: .init(), name: "Grandma Siti", role: "Grandmother", avatarURL: nil, heartRateText: "76 bpm", status: .low),
        .init(id: .init(), name: "Grandpa Budi", role: "Grandfather", avatarURL: nil, heartRateText: "82 bpm", status: .high),
        .init(id: .init(), name: "Uncle Rudi", role: "Uncle", avatarURL: nil, heartRateText: "95 bpm", status: .critical),
        .init(id: .init(), name: "Aunt Lina", role: "Aunt", avatarURL: nil, heartRateText: "72 bpm", status: .medium)
    ]
}
