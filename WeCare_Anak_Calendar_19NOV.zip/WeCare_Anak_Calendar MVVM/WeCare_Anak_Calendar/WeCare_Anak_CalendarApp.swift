//
//  WeCare_Anak_CalendarApp.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 05/11/25.
//

import SwiftUI

@main
struct WeCare_Anak_CalendarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
