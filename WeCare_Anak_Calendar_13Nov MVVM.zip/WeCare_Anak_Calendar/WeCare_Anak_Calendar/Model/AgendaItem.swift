//
//  AgendaItem.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 13/11/25.
//

import Foundation

struct AgendaItem: Identifiable, Codable {
    let id = UUID()
    let title: String
    let description: String
    let time: String
    let status: UrgencyStatus
    let owner: String
}
