//
//  FamilyCalendarVM.swift
//  WeCare_Anak_Calendar
//
//  Created by student on 13/11/25.
//
import Foundation
import Combine
import SwiftUI


@MainActor
final class FamilyCalendarViewModel: ObservableObject {
    // UI state
    @Published var selectedDate: Date = Date()
    @Published var currentMonthOffset = 0
    @Published var selectedPerson: PersonCardViewData? = nil
    
    // Add-agenda sheet state
    @Published var showingAddAgenda = false
    @Published var newAgendaTitle = ""
    @Published var newAgendaDescription = ""
    @Published var newAgendaOwner: PersonCardViewData? = nil
    @Published var newAgendaStatus: UrgencyStatus = .low
    @Published var newAgendaTimeDate = Date()
    
    // Agenda detail
    @Published var selectedAgenda: AgendaItem? = nil
    @Published var showingAgendaDetail = false
    
    // Data
    let persons = SampleData.demoList
    
    // health sample (kept local for calendar color)
    let healthData: [String: [Int: UrgencyStatus]] = [
        "Grandma Siti": [1: .low, 2: .medium, 5: .high, 10: .critical, 15: .low],
        "Grandpa Budi": [3: .low, 6: .high, 9: .medium, 13: .critical],
        "Uncle Rudi": [4: .critical, 8: .medium, 11: .high, 20: .low],
    ]
    
    // agendaData keyed by ownerName -> dateKey -> [AgendaItem]
    @Published var agendaData: [String: [String: [AgendaItem]]] = [:]
    
    init() {
        // seed with some demo agendas
        agendaData = [
            "Grandma Siti": [
                "2025-11-13": [.init(title: "Check blood pressure", description: "Bring meter and record", time: "08:00 AM", status: .low, owner: "Grandma Siti")],
                "2025-11-14": [.init(title: "Take regular medication", description: "Take after breakfast", time: "10:00 AM", status: .medium, owner: "Grandma Siti")]
            ],
            "Grandpa Budi": [
                "2025-11-03": [.init(title: "Leg therapy", description: "Physio at clinic", time: "09:00 AM", status: .high, owner: "Grandpa Budi")]
            ]
        ]
    }
    
    // computed values for view
    var currentDate: Date {
        Calendar.current.date(byAdding: .month, value: currentMonthOffset, to: Date()) ?? Date()
    }
    
    var currentMonthName: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: currentDate)
    }
    
    var daysInMonth: Int {
        Calendar.current.range(of: .day, in: .month, for: currentDate)?.count ?? 30
    }
    
    var currentAgenda: [AgendaItem] {
        let key = dateKey(from: selectedDate)
        if let person = selectedPerson {
            return agendaData[person.name]?[key] ?? []
        } else {
            return persons.flatMap { agendaData[$0.name]?[key] ?? [] }
        }
    }
    
    // MARK: - Agenda management
    
    func saveNewAgenda() {
        guard let owner = newAgendaOwner else { return }
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        let timeString = formatter.string(from: newAgendaTimeDate)
        
        let newItem = AgendaItem(
            title: newAgendaTitle,
            description: newAgendaDescription,
            time: timeString,
            status: newAgendaStatus,
            owner: owner.name
        )
        let key = dateKey(from: selectedDate)
        var personAgendas = agendaData[owner.name] ?? [:]
        var agendasForDay = personAgendas[key] ?? []
        agendasForDay.append(newItem)
        personAgendas[key] = agendasForDay
        agendaData[owner.name] = personAgendas
        
        // reset
        newAgendaTitle = ""
        newAgendaDescription = ""
        newAgendaOwner = nil
        newAgendaStatus = .low
        newAgendaTimeDate = Date()
    }
    
    // MARK: - Calendar color logic
    func colorForDay(_ day: Int) -> Color {
        var combinedStatuses: [UrgencyStatus] = []
        let key = dateKey(forDay: day, in: currentDate)
        
        if let person = selectedPerson {
            if let healthStatus = healthData[person.name]?[day] {
                combinedStatuses.append(healthStatus)
            }
            if let agendas = agendaData[person.name]?[key] {
                combinedStatuses.append(contentsOf: agendas.map { $0.status })
            }
        } else {
            for person in persons {
                if let healthStatus = healthData[person.name]?[day] {
                    combinedStatuses.append(healthStatus)
                }
                if let agendas = agendaData[person.name]?[key] {
                    combinedStatuses.append(contentsOf: agendas.map { $0.status })
                }
            }
        }
        
        if combinedStatuses.contains(.critical) { return Color(hex: "#fa6255") }
        if combinedStatuses.contains(.high) { return Color(hex: "#fdcb46") }
        if combinedStatuses.contains(.medium) { return Color(hex: "#91bef8") }
        if combinedStatuses.contains(.low) { return Color(hex: "#a6d17d") }
        return Color.gray.opacity(0.15)
    }
}
